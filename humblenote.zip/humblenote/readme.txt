=== HumbleNote ===
Contributors: devshubho
Tags: notification, admin notice, custom messages
Requires at least: 5.6
Tested up to: 6.7
Stable tag: 1.0
License: GPL v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A simple WordPress plugin that displays a customizable notification with dismiss and auto-hide options.

== Description ==
HumbleNote allows WordPress admins to show friendly notifications on the dashboard. You can customize the text, set auto-hide duration, and dismiss messages.

== Author ==
- **Name:** Dev.Shubho
- **Insta ID:** dev.shubho
- **WordPress Username:** devshubho
