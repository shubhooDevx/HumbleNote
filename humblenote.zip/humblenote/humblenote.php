<?php
/*
Plugin Name: HumbleNote
Plugin URI: https://github.com/devshubho/humblenote
Description: A simple plugin to display custom announcements anywhere using shortcodes.
Version: 1.2
Author: Dev.Shubho
Author URI: https://www.instagram.com/dev.shubho
License: GPL2
*/

if (!defined('ABSPATH')) {
    exit; // Prevent direct access
}

// Register settings
function hn_register_settings() {
    register_setting('hn_settings_group', 'hn_announcements');
}
add_action('admin_init', 'hn_register_settings');

function hn_add_menu_page() {
    add_menu_page(
        'HumbleNote Announcements',
        'HumbleNote',
        'manage_options',
        'hn-settings',
        'hn_settings_page',
        'dashicons-bell', // Notification-style built-in icon
        25
    );
}

add_action('admin_menu', 'hn_add_menu_page');

// Handle form submission
function hn_handle_form_submission() {
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have permission to perform this action.', 'humblenote'));
    }

    // Get announcements and ensure it's an array
    $announcements = get_option('hn_announcements', []);
    if (!is_array($announcements)) {
        $announcements = []; // Convert string to an empty array if necessary
    }

    if (isset($_POST['hn_add_announcement'])) {
        check_admin_referer('hn_save_announcements', 'hn_nonce');

        $new_announcement = sanitize_text_field($_POST['new_announcement']);

        if (!empty($new_announcement)) {
            $announcements[] = $new_announcement;
            update_option('hn_announcements', $announcements);
        }
    }

    if (isset($_POST['hn_delete_announcement'])) {
        check_admin_referer('hn_save_announcements', 'hn_nonce');

        $index = (int) $_POST['delete_index'];

        if (isset($announcements[$index])) {
            unset($announcements[$index]);
            $announcements = array_values($announcements); // Reindex array
            update_option('hn_announcements', $announcements);
        }
    }

    wp_redirect(admin_url('admin.php?page=hn-settings'));
    exit;
}
add_action('admin_post_hn_save_announcements', 'hn_handle_form_submission');

// Admin settings page
function hn_settings_page() {
    $announcements = get_option('hn_announcements', []);
    if (!is_array($announcements)) {
        $announcements = [];
    }
    ?>
    <div class="wrap">
        <h1>HumbleNote Announcements</h1>
        <p>Add and manage announcements with unique shortcodes.</p>

        <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
            <?php wp_nonce_field('hn_save_announcements', 'hn_nonce'); ?>
            <input type="hidden" name="action" value="hn_save_announcements">
            <table class="form-table">
                <tr>
                    <th><label for="new_announcement">New Announcement</label></th>
                    <td>
                        <input type="text" name="new_announcement" id="new_announcement" class="regular-text" placeholder="Enter announcement text">
                        <button type="submit" name="hn_add_announcement" class="button-primary">Add Announcement</button>
                    </td>
                </tr>
            </table>
        </form>

        <h2>Existing Announcements</h2>
        <table class="widefat">
            <thead>
                <tr>
                    <th>Announcement</th>
                    <th>Shortcode</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($announcements)) : ?>
                    <?php foreach ($announcements as $index => $announcement) : ?>
                        <tr>
                            <td><?php echo esc_html($announcement); ?></td>
                            <td><code>[humblenote id="<?php echo $index; ?>"]</code></td>
                            <td>
                                <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" style="display:inline;">
                                    <?php wp_nonce_field('hn_save_announcements', 'hn_nonce'); ?>
                                    <input type="hidden" name="action" value="hn_save_announcements">
                                    <input type="hidden" name="delete_index" value="<?php echo $index; ?>">
                                    <button type="submit" name="hn_delete_announcement" class="button-link-delete">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="3">No announcements added yet.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <h3>📢 How to Use:</h3>
        <p>Copy and paste the shortcode where you want to display an announcement:</p>
        <code>[humblenote id="0"]</code>, <code>[humblenote id="1"]</code>, etc.

        <hr>
        <p>Developed by <strong>Dev.Shubho</strong> | <a href="https://www.instagram.com/dev.shubho" target="_blank">@dev.shubho</a></p>
    </div>
    <?php
}

// Shortcode function
function hn_announcement_shortcode($atts) {
    $atts = shortcode_atts(['id' => '0'], $atts, 'humblenote');
    $announcements = get_option('hn_announcements', []);
    
    if (!is_array($announcements)) {
        $announcements = [];
    }

    $id = (int) $atts['id'];

    if (!isset($announcements[$id])) {
        return '<!-- No announcement found -->';
    }

    return '<div class="humblenote-box"><span class="humblenote-text">' . esc_html($announcements[$id]) . '</span></div>
    <style>
        .humblenote-box {
            background: #ffcc00;
            color: #000;
            padding: 10px;
            text-align: center;
            font-weight: bold;
            font-size: 16px;
            border-radius: 5px;
            overflow: hidden;
            white-space: nowrap;
        }
        .humblenote-text {
            display: inline-block;
            white-space: nowrap;
            animation: humblenote-marquee 10s linear infinite;
        }
        @keyframes humblenote-marquee {
            from { transform: translateX(100%); }
            to { transform: translateX(-100%); }
        }
    </style>';
}
add_shortcode('humblenote', 'hn_announcement_shortcode');
